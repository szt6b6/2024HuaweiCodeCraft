#include "TaskAssigner.h"

extern int taskIds_map[N][N];

vector<Task> TaskAssigner::taskQueue = vector<Task>(N*N);
int total_robots = robot_num;
int total_tasks = N*N;
vector<vector<float>> cost_matrix(total_robots, vector<float>(total_tasks));  // 任务与执行者的成本矩阵

// later change this，idea robot look around circle by circle
void TaskAssigner::update(vector<Robot> &robot, vector<Berth> &berth, vector<Boat> &boat,
                            char grid[][N], int gds[][N][2], bool gds_locked[][N], 
                            int connectField[][N], int berth_dir_map[berth_num][N][N], int berth_dis_map[berth_num][N][N], int frame)
{
    set<int> r_ids;
    for(int i=0; i<robot_num; i++) {
        if(robot[i].taskT == FREE || robot[i].taskT == GET) r_ids.insert(i);
    }
    if (r_ids.size() <= 0) return; // no robot free, no need update task queue

GATHER_TASK:

    int t_i = 0;
    for(int i=1; i<=n; i++) {
        for(int j=1; j<=n; j++) {
            if(gds[i][j][1] > 0) {
                int berth_i = findBerthToPULL(berth, boat, berth_dis_map, connectField, i, j, frame);
                if(berth_i == -1) continue;
                Task t(frame + gds[i][j][1], i, j, berth[berth_i].robot_at_x, berth[berth_i].robot_at_y, gds[i][j][0], berth_i, berth_dis_map[berth_i][i][j]);
                taskIds_map[i][j] = t_i;
                taskQueue[t_i++] = t;
            }
        }
    }
    total_tasks = t_i;

ASSIGN_TASK:
    // gather all goods to each robot distance
    priority_queue<RobotTaskProfit, vector<RobotTaskProfit>, greater<RobotTaskProfit>> taskBindQue;
    vector<bool> taskAssigned(taskQueue.size(), false);
    init_taskBindQue(taskBindQue, taskIds_map, grid, robot, taskQueue, frame);
    while (!taskBindQue.empty() && !r_ids.empty()) {
        int r_id = taskBindQue.top().r_id;
        int t_id = taskBindQue.top().t_id;
        Task& t = taskQueue[t_id];

        if (r_ids.find(r_id) != r_ids.end() && !taskAssigned[t_id]) {
            // assign task
            r_ids.erase(r_id);
            robot[r_id].setBSxy(t.b_x, t.b_y, t.s_x, t.s_y);
            robot[r_id].taskT = GET;// robot turn to GET
            robot[r_id].get_deadline = t.deadline;
            robot[r_id].dst_pull_berth_id = t.dest_bert_id;
            taskAssigned[t_id] = true;
        }
        taskBindQue.pop();
    }
}

void TaskAssigner::updateForOneRobot(vector<Robot> &robot, vector<Berth> &berth, vector<Boat> &boat, char grid[][N], int gds[][N][2], 
                                        bool gds_locked[][N], int connectField[][N], int berth_dir_map[berth_num][N][N], 
                                        int berth_dis_map[berth_num][N][N], int frame, int r_i)
{
GATHER_TASK:

    int t_i = 0;
    for(int i=1; i<=n; i++) {
        for(int j=1; j<=n; j++) {
            if(gds[i][j][1] > 0 && !gds_locked[i][j]) { 
                int berth_i = findBerthToPULL(berth, boat, berth_dis_map, connectField, i, j, frame);
                if(berth_i == -1) continue;
                Task t(frame+ gds[i][j][1], i, j, berth[berth_i].robot_at_x, berth[berth_i].robot_at_y, gds[i][j][0], berth_i, berth_dis_map[berth_i][i][j]);
                // LOG_see_position(frame, 0, t->b_x, t->b_y, t->s_x, t->s_y);
                taskQueue[t_i++] = t;
            }
        }
    }

ASSIGN_TASK:
    
    Task t;
    LOG_see_task(frame, r_i, t_i);
    double e_profit = double(INT_MIN);
    for(int j=0; j<t_i; j++) {
        Task task = taskQueue[j];

        if(gds_locked[task.b_x][task.b_y]) continue;
        if(connectField[robot[r_i].x][robot[r_i].y] != connectField[task.b_x][task.b_y]) continue;

        int disToGet = 0;
        if(robot[r_i].after_pull_at_berth_id != -1 && grid[robot[r_i].x][robot[r_i].y] == 'B')
            disToGet = berth_dis_map[robot[r_i].after_pull_at_berth_id][task.b_x][task.b_y];
        else
            disToGet = manhattanDistance(robot[r_i].x, robot[r_i].y, task.b_x, task.b_y); // later improve

        if(frame + disToGet + 1 > task.deadline) continue; // good disappear befor robot arrive
        int disToPut = berth_dis_map[task.dest_bert_id][task.b_x][task.b_y];

        // float profit = task.money / (disToGet + disToPut + 0.01) - berth[task.dest_bert_id].average_dis2eachPoint;
        if (frame > 15000 - 2 * min(Berth::max_transport_time, Berth::min_transport_time + berth2berth_dis)) robot_haveBoat_weight = 1000;
        double profit = robot_moneyDis_weight * task.money / (disToGet + 0.01) +
                        robot_avgDis_weight * berth[task.dest_bert_id].average_dis2eachPoint +
                        robot_haveRnum_weight * berth[task.dest_bert_id].r_num +
                        robot_haveBoat_weight * berth[task.dest_bert_id].boat_num;
        // fprintf(stderr, "money = %d, dis = %d\n", task.money, disToGet + disToPut);
        // later consider more elements
        if(e_profit < profit) {
            t = task;
            e_profit = profit;
        }
    }
    if(e_profit != double(INT_MIN)) {
        robot[r_i].setBSxy(t.b_x, t.b_y, t.s_x, t.s_y); 
        robot[r_i].taskT = GET;// robot turn to GET
        robot[r_i].get_deadline = t.deadline;
        robot[r_i].dst_pull_berth_id = t.dest_bert_id;
        gds_locked[t.b_x][t.b_y] = true; // + lock
        LOG_see_position(r_i, r_i, t.b_x, t.b_y, t.s_x, t.s_y);
    }
}

// need to find x, y; which is a place to go, goods assign to berth
int TaskAssigner::findBerthToPULL(vector<Berth> &berth, vector<Boat> &boat, int berth_dis_map[berth_num][N][N], int connectField[][N], int x, int y, int frame)
{
    float e_profit = float(INT_MIN);
    int select = -1;
    for(int i=0; i<berth_num; i++) {
        // find nearst and in same connecField
        if(connectField[x][y] != connectField[berth[i].robot_at_x][berth[i].robot_at_y]) continue;

        float timeWeight = 0;
        if(frame < 15000 - min(Berth::max_transport_time, Berth::min_transport_time + berth2berth_dis) * 2) timeWeight = 0;
        else timeWeight = 1;
        float profit = berth_dismap_weight * berth_dis_map[i][x][y] +
            timeWeight * 4000.0 / berth[i].transport_time +
            timeWeight * 1000 * berth[i].boat_num;

        // fprintf(stderr, "frame %d, align task, berth %d, goodToBerthDis %d\n", frame, i, goodToBerthDis);
        if (e_profit < profit) {
            select = i;
            e_profit = profit;
            // fprintf(stderr, "frame %d, align task, berth %d, selected goodToBerthDis %d\n", frame, i, dis);
        }
    }
    return select;
}